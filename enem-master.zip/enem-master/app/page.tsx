'use client'
import { useEffect, useState, useRef } from 'react'
import { db, initDefaultData, User, Questao, ApiKey, ChatSession, ChatMessage, DynamicPage, Flashcard, Conquista, Redacao, Simulado } from '@/lib/db'
import { hashPassword, generateSalt, generateDeviceId, encryptData } from '@/lib/crypto'
import { callAIWithFallback, getProviderConfig, testApiKey, gerarQuestaoIA, buscarQuestoesReais, gerarFlashcardsIA, corrigirRedacaoIA } from '@/lib/apiManager'

type View = 'dashboard' | 'questoes' | 'flashcards' | 'simulado' | 'redacao' | 'chat' | 'settings' | 'dynamic' | 'pomodoro' | 'ranking' | 'estatisticas'

export default function Home() {
  const [user, setUser] = useState<User | null>(null)
  const [view, setView] = useState<View>('dashboard')
  const [questoes, setQuestoes] = useState<Questao[]>([])
  const [flashcards, setFlashcards] = useState<Flashcard[]>([])
  const [redacoes, setRedacoes] = useState<Redacao[]>([])
  const [dynamicPages, setDynamicPages] = useState<DynamicPage[]>([])
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [conquistas, setConquistas] = useState<Conquista[]>([])
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([])
  const [currentChatId, setCurrentChatId] = useState<string>('')
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [inputMsg, setInputMsg] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [showAuth, setShowAuth] = useState(true)
  const [authMode, setAuthMode] = useState<'login' | 'cadastro'>('login')
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' })
  const [selectedMateria, setSelectedMateria] = useState<string>('Todas')
  const [xpAnimation, setXpAnimation] = useState<{amount:number, type:'gain'|'loss'} | null>(null)
  const [settingsForm, setSettingsForm] = useState({ provider: 'openai' as ApiKey['provider'], key: '', model: '', personalidade: '' })
  const [tema, setTema] = useState<'dark' | 'light'>('dark')
  // Flashcards
  const [flashInstrucao, setFlashInstrucao] = useState('Faça perguntas sobre história, de modo bem difícil, bote 5 alternativas, se eu acertar me dê 20 xp, se errar perca 5 xp, e me dê a resposta e o porquê dela ser a alternativa correta após responder a pergunta')
  const [currentFlashIndex, setCurrentFlashIndex] = useState(0)
  const [showFlashAnswer, setShowFlashAnswer] = useState(false)
  const [selectedFlashAlt, setSelectedFlashAlt] = useState<number | null>(null)
  const [flashMode, setFlashMode] = useState<'criar' | 'estudar'>('criar')
  // Pomodoro
  const [pomodoroTime, setPomodoroTime] = useState(25*60)
  const [pomodoroActive, setPomodoroActive] = useState(false)
  const [pomodoroMode, setPomodoroMode] = useState<'foco' | 'pausa'>('foco')
  const [pomodoroSessions, setPomodoroSessions] = useState(0)
  // Simulado
  const [simuladoAtivo, setSimuladoAtivo] = useState<Simulado | null>(null)
  const [simuladoQuestoes, setSimuladoQuestoes] = useState<Questao[]>([])
  const [simuladoRespostas, setSimuladoRespostas] = useState<Record<number, number>>({})
  const [simuladoTime, setSimuladoTime] = useState(0)
  const [simuladoTimerActive, setSimuladoTimerActive] = useState(false)
  // Redação
  const [redacaoTema, setRedacaoTema] = useState('A persistência da violência contra a mulher na sociedade brasileira')
  const [redacaoTexto, setRedacaoTexto] = useState('')
  // Busca
  const [busca, setBusca] = useState('')
  // Offline PWA
  const [isOnline, setIsOnline] = useState(true)
  const [showInstall, setShowInstall] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const init = async () => {
      await initDefaultData()
      setDynamicPages(await db.dynamicPages.toArray())
      setQuestoes(await db.questoes.toArray())
      setFlashcards(await db.flashcards.orderBy('proximaRevisao').toArray())
      setRedacoes(await db.redacoes.orderBy('createdAt').reverse().toArray())
      setApiKeys(await db.apikeys.toArray())
      setChatSessions(await db.chatSessions.orderBy('updatedAt').reverse().toArray())
      const savedUserId = localStorage.getItem('enem_user_id')
      if (savedUserId) {
        const u = await db.users.get(parseInt(savedUserId))
        if (u) {
          setUser(u); setShowAuth(false)
          setConquistas(await db.conquistas.where('userId').equals(u.id!).toArray())
        }
      }
      const savedTema = localStorage.getItem('enem_tema_ui') as any
      if (savedTema) setTema(savedTema)
      const savedPomodoro = localStorage.getItem('pomodoro_sessions')
      if (savedPomodoro) setPomodoroSessions(parseInt(savedPomodoro))
    }
    init()

    // PWA Offline detection
    setIsOnline(navigator.onLine)
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    // PWA install prompt
    const handleBeforeInstall = (e: any) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowInstall(true)
    }
    window.addEventListener('beforeinstallprompt', handleBeforeInstall)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall)
    }
  }, [])

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chatMessages])
  useEffect(() => { if (currentChatId) db.chatMessages.where('chatId').equals(currentChatId).sortBy('timestamp').then(setChatMessages) }, [currentChatId])

  useEffect(() => {
    let interval: any
    if (pomodoroActive && pomodoroTime > 0) interval = setInterval(() => setPomodoroTime(t => t-1), 1000)
    else if (pomodoroActive && pomodoroTime === 0) {
      const isFoco = pomodoroMode === 'foco'
      if (isFoco) {
        addXP(25, 'gain')
        const newSessions = pomodoroSessions + 1
        setPomodoroSessions(newSessions); localStorage.setItem('pomodoro_sessions', newSessions.toString())
        setPomodoroMode('pausa'); setPomodoroTime(5*60); alert('🎉 Foco completo! +25 XP. Pausa 5 min.')
      } else { setPomodoroMode('foco'); setPomodoroTime(25*60); alert('Pausa acabou!') }
      setPomodoroActive(false)
    }
    return () => clearInterval(interval)
  }, [pomodoroActive, pomodoroTime, pomodoroMode])

  useEffect(() => {
    let interval: any
    if (simuladoTimerActive) interval = setInterval(() => setSimuladoTime(t=>t+1), 1000)
    return () => clearInterval(interval)
  }, [simuladoTimerActive])

  const toggleTema = () => { const novo = tema==='dark'?'light':'dark'; setTema(novo); localStorage.setItem('enem_tema_ui', novo) }

  const handleAuth = async () => {
    if (!authForm.email || !authForm.password) return alert('Preencha tudo')
    if (authMode === 'cadastro') {
      const exists = await db.users.where('email').equals(authForm.email).first()
      if (exists) return alert('Email já cadastrado')
      const salt = generateSalt(); const hash = await hashPassword(authForm.password, salt)
      const id = await db.users.add({ email: authForm.email, name: authForm.name || authForm.email.split('@')[0], passwordHash: hash, salt, createdAt: Date.now(), xp: 0, level: 1, streak: 0, lastStudy: Date.now() })
      const newUser = await db.users.get(id as number)
      setUser(newUser!); localStorage.setItem('enem_user_id', id.toString()); setShowAuth(false)
    } else {
      const u = await db.users.where('email').equals(authForm.email).first()
      if (!u) return alert('Usuário não encontrado')
      const hash = await hashPassword(authForm.password, u.salt)
      if (hash !== u.passwordHash) return alert('Senha incorreta')
      setUser(u); localStorage.setItem('enem_user_id', u.id!.toString()); setShowAuth(false)
      setConquistas(await db.conquistas.where('userId').equals(u.id!).toArray())
    }
  }

  const logout = () => { localStorage.removeItem('enem_user_id'); setUser(null); setShowAuth(true) }

  const addXP = async (amount: number, type: 'gain' | 'loss' = 'gain') => {
    if (!user?.id) return
    const finalAmount = type === 'loss' ? -Math.abs(amount) : Math.abs(amount)
    const newXP = Math.max(0, user.xp + finalAmount)
    const newLevel = Math.floor(newXP / 100) + 1
    const leveledUp = newLevel > user.level
    await db.users.update(user.id, { xp: newXP, level: newLevel, lastStudy: Date.now() })
    setUser({ ...user, xp: newXP, level: newLevel })
    setXpAnimation({ amount: finalAmount, type }); setTimeout(()=>setXpAnimation(null), 2000)
    if (leveledUp) { await db.conquistas.add({ userId: user.id, titulo: `Nível ${newLevel}`, descricao: `Chegou ao nível ${newLevel}!`, icon: '🚀', xp: 50, timestamp: Date.now() }); setConquistas(await db.conquistas.where('userId').equals(user.id).toArray()); alert(`🎉 NÍVEL ${newLevel}!`) }
  }

  const responderQuestao = async (q: Questao, alternativa: number) => {
    const acertou = alternativa === q.correta
    if (user?.id && q.id) await db.progressos.add({ userId: user.id, questaoId: q.id, acertou, tempo: 30, timestamp: Date.now(), xpGanho: acertou ? 15 : 5 })
    await addXP(acertou ? 15 : 5, acertou ? 'gain' : 'loss')
    alert(acertou ? `✅ Acertou! +15 XP - ${q.explicacao}` : `❌ Errou. Resposta: ${q.alternativas[q.correta]} - ${q.explicacao}`)
  }

  const gerarQuestao = async () => {
    setIsGenerating(true)
    const result = await gerarQuestaoIA(selectedMateria === 'Todas' ? 'Matemática' : selectedMateria, 'medio')
    if (result.success && result.data?.enunciado) {
      const nova: Questao = { enunciado: result.data.enunciado, alternativas: result.data.alternativas, correta: result.data.correta, materia: selectedMateria === 'Todas' ? 'Matemática' : selectedMateria, dificuldade: 'medio', fonte: 'ia', explicacao: result.data.explicacao, createdAt: Date.now() }
      const id = await db.questoes.add(nova); setQuestoes([...questoes, { ...nova, id: id as number }])
    } else alert('Configure APIs. Erro: ' + result.error)
    setIsGenerating(false)
  }

  const buscarReais = async () => { setIsGenerating(true); const result = await buscarQuestoesReais(selectedMateria); if (result.success) { alert(`Encontradas ${result.data.length} questões reais! Console.`); console.log(result.data) } else alert('Configure Tavily'); setIsGenerating(false) }

  const gerarFlashcards = async () => {
    if (!flashInstrucao.trim()) return alert('Descreva como quer')
    setIsGenerating(true)
    const result = await gerarFlashcardsIA(flashInstrucao)
    if (result.success && Array.isArray(result.data)) {
      const novos: Flashcard[] = result.data.map((f: any) => ({
        frente: f.frente, verso: f.verso || f.alternativas?.[f.correta] || '', alternativas: f.alternativas, correta: f.correta, explicacao: f.explicacao,
        materia: f.materia || 'Geral', dificuldade: f.dificuldade || 'medio', xpGanho: f.xpGanho || 20, xpPerda: f.xpPerda || 5,
        instrucaoOriginal: flashInstrucao, acertos: 0, erros: 0, proximaRevisao: Date.now(), createdAt: Date.now()
      }))
      await db.flashcards.bulkAdd(novos); setFlashcards(await db.flashcards.toArray()); setFlashMode('estudar'); setCurrentFlashIndex(0); setShowFlashAnswer(false); alert(`${novos.length} flashcards via ${result.providerUsed}!`)
    } else {
      const fallback: Flashcard = {
        frente: `Exemplo local: O que é fotossíntese? [${flashInstrucao.slice(0,60)}]`,
        verso: 'Conversão luz em energia química', alternativas: ['A) Respiração','B) Fotossíntese - conversão luz em energia','C) Digestão','D) Fermentação','E) Osmose'], correta: 1,
        explicacao: 'Fotossíntese ocorre nos cloroplastos, produz glicose e O2.', materia: 'Biologia', dificuldade: 'dificil', xpGanho: 20, xpPerda: 5, instrucaoOriginal: flashInstrucao, acertos: 0, erros: 0, proximaRevisao: Date.now(), createdAt: Date.now()
      }
      await db.flashcards.add(fallback); setFlashcards(await db.flashcards.toArray()); alert('Sem API, criei exemplo local. Configure Groq/Gemini para IA real.')
    }
    setIsGenerating(false)
  }

  const responderFlashcard = async (alt: number) => {
    const card = flashcards[currentFlashIndex]; if (!card) return
    setSelectedFlashAlt(alt); setShowFlashAnswer(true)
    const acertou = alt === card.correta
    await db.flashcards.update(card.id!, { acertos: acertou ? card.acertos+1 : card.acertos, erros: acertou ? card.erros : card.erros+1, proximaRevisao: acertou ? Date.now()+24*60*60*1000 : Date.now()+10*60*1000 })
    await addXP(acertou ? card.xpGanho : card.xpPerda, acertou ? 'gain' : 'loss')
    setFlashcards(await db.flashcards.toArray())
  }

  const proximoFlashcard = () => { setShowFlashAnswer(false); setSelectedFlashAlt(null); if (currentFlashIndex < flashcards.length-1) setCurrentFlashIndex(currentFlashIndex+1); else { alert('🎉 Todos revisados!'); setCurrentFlashIndex(0) } }

  // Simulado
  const iniciarSimulado = async (qtd: number = 10) => {
    const todas = await db.questoes.toArray()
    if (todas.length < qtd) return alert(`Só tem ${todas.length} questões. Gere mais em Questões.`)
    const embaralhadas = [...todas].sort(()=>0.5-Math.random()).slice(0,qtd)
    setSimuladoQuestoes(embaralhadas)
    setSimuladoRespostas({})
    setSimuladoTime(0)
    setSimuladoTimerActive(true)
    const novo: Simulado = { userId: user?.id, questoesIds: embaralhadas.map(q=>q.id!), respostas: [], tempoTotal: 0, finalizado: false, createdAt: Date.now() }
    const id = await db.simulados.add(novo)
    setSimuladoAtivo({ ...novo, id: id as number })
    setView('simulado')
  }

  const finalizarSimulado = async () => {
    setSimuladoTimerActive(false)
    let acertos = 0
    simuladoQuestoes.forEach(q=>{
      if (simuladoRespostas[q.id!] === q.correta) acertos++
    })
    const nota = Math.round((acertos / simuladoQuestoes.length)*1000)
    await addXP(acertos*10, 'gain')
    if (simuladoAtivo?.id) {
      await db.simulados.update(simuladoAtivo.id, { respostas: Object.entries(simuladoRespostas).map(([qid, alt])=>({questaoId: parseInt(qid), alternativa: alt as number, tempo: 30})), nota, tempoTotal: simuladoTime, finalizado: true })
    }
    alert(`Simulado finalizado! ${acertos}/${simuladoQuestoes.length} acertos - Nota: ${nota} - Tempo: ${Math.floor(simuladoTime/60)}min - +${acertos*10} XP`)
    setSimuladoAtivo(null)
  }

  // Redação
  const corrigirRedacao = async () => {
    if (!redacaoTexto.trim() || redacaoTexto.length < 100) return alert('Escreva pelo menos 100 caracteres')
    setIsGenerating(true)
    const result = await corrigirRedacaoIA(redacaoTema, redacaoTexto)
    if (result.success && result.data?.notaTotal) {
      const nova: Redacao = { userId: user?.id, tema: redacaoTema, texto: redacaoTexto, notaTotal: result.data.notaTotal, competencias: result.data.competencias, feedback: result.data.feedback + '\n\nSugestão: ' + (result.data.sugestao||''), createdAt: Date.now() }
      const id = await db.redacoes.add(nova)
      setRedacoes([{...nova, id: id as number}, ...redacoes])
      await addXP(Math.floor(result.data.notaTotal/100)*5, 'gain')
      alert(`Redação corrigida! Nota: ${result.data.notaTotal} - +${Math.floor(result.data.notaTotal/100)*5} XP via ${result.providerUsed}`)
    } else {
      // Fallback local
      const notaFake = 600 + Math.floor(Math.random()*300)
      const nova: Redacao = { userId: user?.id, tema: redacaoTema, texto: redacaoTexto, notaTotal: notaFake, competencias: {c1:120,c2:140,c3:120,c4:120,c5:100}, feedback: 'Correção offline (sem API). Configure Groq/Gemini/OpenAI em Configurações para correção real C1-C5. Texto tem boa estrutura, melhore conectivos.', createdAt: Date.now() }
      const id = await db.redacoes.add(nova)
      setRedacoes([{...nova, id: id as number}, ...redacoes])
      alert(`Sem API, nota estimada: ${notaFake}. Configure API para correção real.`)
    }
    setIsGenerating(false)
  }

  const instalarPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      if (outcome === 'accepted') setShowInstall(false)
      setDeferredPrompt(null)
    } else {
      alert('Para instalar:\n\n📱 Android: Menu ⋮ → Instalar app / Adicionar à tela inicial\n🍎 iPhone: Compartilhar → Adicionar à Tela de Início\n💻 Chrome: Ícone de instalação na barra de endereço')
    }
  }

  const exportarDados = async (tipo: 'json' | 'flashcards-pdf') => {
    if (tipo==='json') {
      const dados = { user, questoes: await db.questoes.toArray(), flashcards: await db.flashcards.toArray(), redacoes: await db.redacoes.toArray(), progressos: await db.progressos.toArray(), conquistas, simulados: await db.simulados.toArray(), data: new Date().toISOString(), offline: true, version: 'v3-offline' }
      const blob = new Blob([JSON.stringify(dados, null, 2)], {type:'application/json'})
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href=url; a.download=`enem-master-backup-offline-${Date.now()}.json`; a.click()
    } else {
      const conteudo = flashcards.map(f=>`PERGUNTA: ${f.frente}\nRESPOSTA: ${f.verso}\nALTERNATIVAS: ${f.alternativas?.join(' | ')}\nCORRETA: ${f.alternativas?.[f.correta||0]}\nEXPLICAÇÃO: ${f.explicacao}\nMATÉRIA: ${f.materia} | DIFICULDADE: ${f.dificuldade} | XP: +${f.xpGanho}/-${f.xpPerda}\n---`).join('\n\n')
      const blob = new Blob([conteudo], {type:'text/plain'})
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href=url; a.download=`flashcards-offline-${Date.now()}.txt`; a.click()
      alert('Exportado TXT offline. Para PDF, abra o TXT e use Ctrl+P → Salvar como PDF no navegador.')
    }
  }

  const salvarApiKey = async () => {
    if (!settingsForm.key) return alert('Cole a chave')
    const deviceId = generateDeviceId(); const encrypted = await encryptData(settingsForm.key, deviceId)
    const config = getProviderConfig(settingsForm.provider as any)
    const id = await db.apikeys.add({ provider: settingsForm.provider as any, keyEncrypted: encrypted, model: settingsForm.model || config.models[0], personalidade: settingsForm.personalidade, ativo: true, status: 'nao_testado', prioridade: apiKeys.length })
    setApiKeys(await db.apikeys.toArray()); setSettingsForm({ provider: 'openai', key: '', model: '', personalidade: '' })
    const saved = await db.apikeys.get(id as number)
    if (saved) { const ok = await testApiKey(saved); await db.apikeys.update(id as number, { status: ok ? 'ok' : 'erro', lastTest: Date.now() }); setApiKeys(await db.apikeys.toArray()) }
  }

  const testarKey = async (k: ApiKey) => { await db.apikeys.update(k.id!, { status: 'testando' }); setApiKeys(await db.apikeys.toArray()); const ok = await testApiKey(k); await db.apikeys.update(k.id!, { status: ok ? 'ok' : 'erro', lastTest: Date.now() }); setApiKeys(await db.apikeys.toArray()) }
  const deletarKey = async (id: number) => { await db.apikeys.delete(id); setApiKeys(await db.apikeys.toArray()) }

  const criarNovoChat = async () => {
    const id = 'chat_' + Date.now()
    const session: ChatSession = { id, title: 'Nova conversa', createdAt: Date.now(), updatedAt: Date.now() }
    await db.chatSessions.add(session); setChatSessions([session, ...chatSessions]); setCurrentChatId(id); setChatMessages([])
  }

  const detectarComandoModificacao = async (texto: string): Promise<boolean> => {
    const lower = texto.toLowerCase()
    if (lower.includes('/criar pagina') || lower.includes('crie uma página') || lower.includes('criar página')) {
      const materias = ['biologia','matemática','matematica','história','historia','química','quimica','física','fisica','geografia','português','álgebra','algebra']
      let materiaDetectada='Geral'; let icon='📚'
      for (const m of materias) { if (lower.includes(m)) { materiaDetectada=m.charAt(0).toUpperCase()+m.slice(1); if (m.includes('bio')) icon='🧬'; if (m.includes('mat')||m.includes('alge')) icon='📐'; break } }
      const slug = materiaDetectada.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,'-')+'-'+Date.now()
      await db.dynamicPages.add({ slug, title: materiaDetectada, materia: materiaDetectada, content: `Página de ${materiaDetectada} criada via chat! ${texto}`, icon, createdAt: Date.now(), createdBy: 'ia' })
      setDynamicPages(await db.dynamicPages.toArray())
      const msg: ChatMessage = { chatId: currentChatId, role: 'assistant', content: `✅ Criei página **${materiaDetectada}** ${icon} - já no menu!`, timestamp: Date.now() }
      await db.chatMessages.add(msg); setChatMessages(prev=>[...prev, msg]); return true
    }
    if (lower.includes('flashcard')) { setFlashInstrucao(texto); setView('flashcards'); setFlashMode('criar'); const msg: ChatMessage = { chatId: currentChatId, role: 'assistant', content: `🃏 Indo pra Flashcards com: "${texto}". Clique Gerar!`, timestamp: Date.now() }; await db.chatMessages.add(msg); setChatMessages(prev=>[...prev, msg]); return true }
    return false
  }

  const enviarMensagemChat = async () => {
    if (!inputMsg.trim() || !currentChatId) return
    const userMsg: ChatMessage = { chatId: currentChatId, role: 'user', content: inputMsg, timestamp: Date.now() }
    await db.chatMessages.add(userMsg); setChatMessages(prev=>[...prev, userMsg]); const texto=inputMsg; setInputMsg(''); setIsGenerating(true)
    const foiComando = await detectarComandoModificacao(texto)
    if (foiComando) { setIsGenerating(false); return }
    const historico = [...chatMessages, userMsg].slice(-10).map(m=>({role:m.role, content:m.content}))
    const keys = await db.apikeys.toArray()
    const personalidadeAtiva = keys.find(k=>k.personalidade)?.personalidade || 'Você é tutor ENEM especialista.'
    const result = await callAIWithFallback([{role:'system', content:personalidadeAtiva}, ...historico], 'chat')
    let conteudo = result.success ? result.data + `\n\n_— via ${result.providerUsed}_` : `Offline! Você tem ${user?.xp||0} XP. Configure APIs. Comandos: /criar pagina biologia`
    const assistantMsg: ChatMessage = { chatId: currentChatId, role: 'assistant', content: conteudo, timestamp: Date.now(), providerUsed: result.providerUsed, modelUsed: result.modelUsed }
    await db.chatMessages.add(assistantMsg); setChatMessages(prev=>[...prev, assistantMsg])
    if (chatMessages.length===0) { await db.chatSessions.update(currentChatId, { title: texto.slice(0,30), updatedAt: Date.now() }); setChatSessions(await db.chatSessions.orderBy('updatedAt').reverse().toArray()) }
    setIsGenerating(false)
  }

  if (showAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-950 via-slate-900 to-black flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          <div className="text-center mb-8"><div className="w-16 h-16 bg-gradient-to-br from-violet-600 to-blue-600 rounded-2xl mx-auto flex items-center justify-center text-2xl mb-4">🎓</div><h1 className="text-3xl font-bold">ENEM Master v3</h1><p className="text-zinc-400 mt-2">Flashcards + Simulado + Redação IA</p><p className="text-xs text-zinc-500 mt-1">Auto-mod + Pomodoro + Export PDF</p></div>
          <div className="space-y-4">
            {authMode==='cadastro' && <input value={authForm.name} onChange={e=>setAuthForm({...authForm, name:e.target.value})} placeholder="Seu nome" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 outline-none focus:border-violet-600" />}
            <input value={authForm.email} onChange={e=>setAuthForm({...authForm, email:e.target.value})} placeholder="Email" type="email" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 outline-none focus:border-violet-600" />
            <input value={authForm.password} onChange={e=>setAuthForm({...authForm, password:e.target.value})} placeholder="Senha" type="password" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-3 outline-none focus:border-violet-600" />
            <button onClick={handleAuth} className="w-full bg-gradient-to-r from-violet-600 to-blue-600 rounded-xl py-3 font-bold hover:opacity-90 transition">{authMode==='login'?'Entrar':'Criar conta segura'}</button>
            <button onClick={()=>setAuthMode(authMode==='login'?'cadastro':'login')} className="w-full text-sm text-zinc-400 hover:text-white">{authMode==='login'?'Não tem conta? Cadastre-se':'Já tem conta? Entrar'}</button>
          </div>
        </div>
      </div>
    )
  }

  const filteredQuestoes = questoes.filter(q=> (selectedMateria==='Todas' || q.materia===selectedMateria) && (busca==='' || q.enunciado.toLowerCase().includes(busca.toLowerCase())))
  const isLight = tema==='light'
  const bgMain = isLight ? 'bg-zinc-50 text-zinc-900' : 'bg-[#0a0a0a] text-white'
  const bgSidebar = isLight ? 'bg-white border-zinc-200' : 'bg-zinc-900 border-zinc-800'
  const bgCard = isLight ? 'bg-white border-zinc-200' : 'bg-zinc-900 border-zinc-800'
  const bgInput = isLight ? 'bg-zinc-100 border-zinc-300 text-zinc-900' : 'bg-zinc-800 border-zinc-700 text-white'

  return (
    <div className={`min-h-screen flex ${bgMain}`}>
      <div className={`w-64 ${bgSidebar} border-r flex flex-col`}>
        <div className="p-4 border-b border-zinc-800 flex justify-between items-center">
          <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">🎓</div><div><div className="font-bold">ENEM Master</div><div className="text-xs text-zinc-400">v3 completo</div></div></div>
          <button onClick={toggleTema} className="text-sm bg-zinc-800 hover:bg-zinc-700 w-8 h-8 rounded-full flex items-center justify-center">{tema==='dark'?'☀️':'🌙'}</button>
        </div>
        {user && <div className="m-3 bg-zinc-800 rounded-xl p-3"><div className="text-sm font-medium">{user.name}</div><div className="text-xs text-zinc-400">{user.email}</div><div className="mt-2"><div className="flex justify-between text-xs mb-1"><span>Nv {user.level}</span><span>{user.xp} XP</span></div><div className="h-2 bg-zinc-700 rounded-full overflow-hidden"><div className="h-full xp-bar transition-all" style={{width:`${(user.xp%100)}%`}}></div></div></div></div>}
        <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin">
          <button onClick={()=>setView('dashboard')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='dashboard'?'bg-zinc-800 text-white':'text-zinc-400 hover:bg-zinc-800/50'}`}>📊 Dashboard</button>
          <button onClick={()=>setView('questoes')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='questoes'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>📝 Questões ({filteredQuestoes.length})</button>
          <button onClick={()=>{setView('flashcards'); setFlashMode('criar')}} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='flashcards'?'bg-violet-900/50 border border-violet-600 text-white':'text-zinc-400 hover:bg-zinc-800/50'}`}>🃏 Flashcards ({flashcards.length})</button>
          <button onClick={()=>setView('simulado')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='simulado'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'} border border-transparent ${view==='simulado'?'border-blue-600':''}`}>📝 Simulado 180q <span className="ml-auto text-[10px] bg-blue-600 px-2 py-0.5 rounded-full">NOVO</span></button>
          <button onClick={()=>setView('redacao')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='redacao'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'} border ${view==='redacao'?'border-green-600':''}`}>✍️ Redação IA <span className="ml-auto text-[10px] bg-green-600 px-2 py-0.5 rounded-full">NOVO</span></button>
          <button onClick={()=>setView('pomodoro')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='pomodoro'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>🍅 Pomodoro ({pomodoroSessions})</button>
          <button onClick={()=>setView('estatisticas')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='estatisticas'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>📈 Estatísticas</button>
          <button onClick={()=>setView('ranking')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='ranking'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>🏆 Ranking</button>
          <button onClick={()=>setView('chat')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='chat'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>💬 Chat IA</button>
          <button onClick={()=>setView('settings')} className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center gap-3 ${view==='settings'?'bg-zinc-800':'text-zinc-400 hover:bg-zinc-800/50'}`}>⚙️ APIs <span className="ml-auto text-xs bg-zinc-700 px-2 py-0.5 rounded-full">{apiKeys.filter(k=>k.status==='ok').length}/{apiKeys.length}</span>{apiKeys.filter(k=>k.status==='erro').length>0 && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}</button>
          <div className="pt-4"><div className="text-xs text-zinc-500 px-3 mb-2">PÁGINAS DINÂMICAS</div>{dynamicPages.map(p=><button key={p.id} onClick={()=>setView('dynamic')} className="w-full text-left px-3 py-2 rounded-xl text-sm text-zinc-400 hover:bg-zinc-800/50 flex items-center gap-2"><span>{p.icon}</span> {p.title}</button>)}</div>
          <div className="pt-4 px-3 space-y-2">
            <button onClick={()=>exportarDados('json')} className="w-full text-xs bg-zinc-800 hover:bg-zinc-700 rounded-xl py-2">💾 Exportar backup JSON</button>
            <button onClick={()=>exportarDados('flashcards-pdf')} className="w-full text-xs bg-zinc-800 hover:bg-zinc-700 rounded-xl py-2">📄 Exportar flashcards TXT</button>
          </div>
        </div>
        <div className="p-3 border-t border-zinc-800"><button onClick={logout} className="w-full text-xs text-zinc-500 hover:text-white">Sair</button></div>
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Offline banner */}
        {!isOnline && (
          <div className="bg-amber-900/80 border-b border-amber-700 text-amber-200 px-4 py-2 text-sm flex items-center justify-between">
            <span>📴 Modo offline ativo - Tudo funciona localmente! Banco no seu dispositivo, criptografado.</span>
            <span className="text-xs bg-amber-800 px-2 py-1 rounded-full">Offline total</span>
          </div>
        )}
        {showInstall && (
          <div className="bg-violet-900/80 border-b border-violet-700 text-white px-4 py-3 flex items-center justify-between">
            <span>📲 Instale como app! Funciona 100% offline, igual WhatsApp.</span>
            <div className="flex gap-2">
              <button onClick={instalarPWA} className="bg-white text-violet-900 px-4 py-1.5 rounded-full text-sm font-bold">Instalar app</button>
              <button onClick={()=>setShowInstall(false)} className="bg-violet-800 px-3 py-1.5 rounded-full text-sm">X</button>
            </div>
          </div>
        )}
        {xpAnimation && <div className={`fixed top-20 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full font-bold animate-bounce z-50 ${xpAnimation.type==='gain'?'bg-gradient-to-r from-violet-600 to-blue-600':'bg-gradient-to-r from-red-600 to-orange-600'}`}>{xpAnimation.amount>0?'+':''}{xpAnimation.amount} XP!</div>}

        {view==='dashboard' && (
          <div className="flex-1 overflow-y-auto p-8">
            <div className="flex justify-between items-center mb-6"><div><h1 className="text-3xl font-bold">Olá, {user?.name} 👋 {isOnline ? '🌐' : '📴'}</h1><p className="text-zinc-400">v4 offline total + PWA instalável {isOnline ? '(online)' : '(offline - tudo funciona local)'}</p></div><div className="flex gap-2"><input value={busca} onChange={e=>setBusca(e.target.value)} placeholder="🔍 Buscar..." className={`${bgInput} border rounded-xl px-4 py-2 text-sm w-48`} /><button onClick={instalarPWA} className="bg-zinc-800 hover:bg-zinc-700 px-4 py-2 rounded-xl text-sm">📲 Instalar app</button></div></div>

            <div className={`${isOnline ? 'bg-green-950/30 border-green-800' : 'bg-amber-950/30 border-amber-800'} border rounded-2xl p-4 mb-6 flex items-center justify-between`}>
              <div className="flex items-center gap-3"><div className={`w-3 h-3 rounded-full ${isOnline?'bg-green-500 animate-pulse':'bg-amber-500'}`}></div><div><div className="font-bold text-sm">{isOnline ? 'Online - APIs funcionando' : 'Offline - Modo local total ativo'}</div><div className="text-xs text-zinc-400">{isOnline ? 'Geração IA, correção redação e busca real funcionando' : 'Banco IndexedDB criptografado no seu dispositivo. Questões, flashcards, simulado, pomodoro tudo funciona sem internet.'}</div></div></div>
              <div className="text-xs bg-zinc-800 px-3 py-1.5 rounded-full">{isOnline ? '🌐 Online' : '📴 Offline PWA'}</div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-8">
              <div className={`${bgCard} border rounded-2xl p-5`}><div className="text-2xl mb-1">{user?.xp||0}</div><div className="text-sm text-zinc-400">XP Total</div><div className="text-xs text-violet-400 mt-1">Nível {user?.level} • {conquistas.length} conquistas</div></div>
              <div className={`${bgCard} border rounded-2xl p-5`}><div className="text-2xl mb-1">{questoes.length}</div><div className="text-sm text-zinc-400">Questões offline</div><div className="text-xs text-blue-400 mt-1">{questoes.filter(q=>q.fonte==='ia').length} IA + {flashcards.length} flashcards</div></div>
              <div className={`${bgCard} border rounded-2xl p-5`}><div className="text-2xl mb-1">{redacoes.length}</div><div className="text-sm text-zinc-400">Redações</div><div className="text-xs text-green-400 mt-1">{redacoes.length>0?`Última: ${redacoes[0]?.notaTotal}`:'Offline funciona'}</div></div>
              <div className={`${bgCard} border rounded-2xl p-5`}><div className="text-2xl mb-1">{pomodoroSessions}</div><div className="text-sm text-zinc-400">Pomodoros</div><div className="text-xs text-orange-400 mt-1">🍅 {Math.floor(pomodoroSessions*25/60)}h • PWA</div></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className={`${bgCard} border rounded-2xl p-6 border-violet-900/50`}><h2 className="font-bold mb-3">📴 Sistema Offline Total (NOVO v4)</h2><div className="space-y-2 text-sm text-zinc-300"><p>✅ <b>Funciona sem internet:</b> login, questões, flashcards com revisão espaçada, simulado cronometrado, pomodoro, XP, conquistas, páginas dinâmicas</p><p>✅ <b>PWA instalável:</b> no celular clique em "Instalar app" - vira app igual WhatsApp, ícone na tela inicial</p><p>✅ <b>Service Worker:</b> cacheia tudo, abre mesmo offline, sync quando voltar online</p><p>✅ <b>Banco local criptografado:</b> IndexedDB + AES-GCM no seu dispositivo, sem risco</p><p className="text-amber-400">❌ Precisa internet: gerar novas questões IA, corrigir redação IA, buscar reais via Tavily, chat IA real (mas tem fallback local)</p></div></div>
              <div className={`${bgCard} border rounded-2xl p-6`}><h2 className="font-bold mb-3">🃏 Flashcards + Simulado + Redação</h2><div className="space-y-1 text-sm text-zinc-400"><p>• Flashcards custom por prompt: "5 alt +20/-5 com porquê"</p><p>• Simulado 10-180q cronometrado nota TRI</p><p>• Redação C1-C5 nota 0-1000 com IA + fallback</p><p>• Pomodoro + ranking + conquistas + export JSON/TXT</p><p>• Auto-mod: "/criar pagina biologia" em tempo real</p><p>• Tema claro/escuro ☀️🌙 + busca + offline indicator</p></div><button onClick={instalarPWA} className="mt-4 w-full bg-gradient-to-r from-violet-600 to-blue-600 rounded-xl py-2.5 font-bold">📲 Instalar como app offline</button></div>
            </div>
          </div>
        )}

        {view==='flashcards' && (
          <div className="flex-1 overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-6"><h1 className="text-2xl font-bold">🃏 Flashcards Inteligentes</h1><div className="flex gap-2"><button onClick={()=>setFlashMode('criar')} className={`px-4 py-2 rounded-xl text-sm ${flashMode==='criar'?'bg-violet-600':'bg-zinc-800'}`}>Criar</button><button onClick={()=>setFlashMode('estudar')} className={`px-4 py-2 rounded-xl text-sm ${flashMode==='estudar'?'bg-violet-600':'bg-zinc-800'}`}>Estudar ({flashcards.length})</button><button onClick={()=>exportarDados('flashcards-pdf')} className="bg-zinc-800 px-3 py-2 rounded-xl text-xs">📄 Exportar</button></div></div>
            {flashMode==='criar' ? (
              <div className="max-w-3xl">
                <div className={`${bgCard} border rounded-2xl p-6 border-violet-900/50`}><h3 className="font-bold mb-2">Descreva detalhadamente como quer os flashcards</h3><textarea value={flashInstrucao} onChange={e=>setFlashInstrucao(e.target.value)} className={`w-full ${bgInput} border rounded-xl p-4 text-sm h-32`} /><button onClick={gerarFlashcards} disabled={isGenerating} className="mt-4 w-full bg-gradient-to-r from-violet-600 to-blue-600 rounded-xl py-3 font-bold disabled:opacity-50">{isGenerating?'Gerando 5 via IA...':'✨ Gerar 5 Flashcards com IA (com fallback)'}</button>
                <div className="mt-4 grid grid-cols-3 gap-2 text-xs"><button onClick={()=>setFlashInstrucao('Faça 5 flashcards de história do Brasil, muito difícil, 5 alternativas, +20 xp se acertar -10 se errar, explique por que é correta')} className="bg-zinc-800 p-2 rounded-xl hover:bg-zinc-700">História difícil 5 alt</button><button onClick={()=>setFlashInstrucao('Crie flashcards de álgebra linear, nível médio, 4 alternativas, +15 xp acerto, -3 erro, com explicação detalhada')} className="bg-zinc-800 p-2 rounded-xl hover:bg-zinc-700">Álgebra médio</button><button onClick={()=>setFlashInstrucao('Flashcards de biologia sobre mitose e meiose, fácil, 4 alternativas, +10 xp, mostre resposta e porquê')} className="bg-zinc-800 p-2 rounded-xl hover:bg-zinc-700">Biologia fácil</button></div></div>
              </div>
            ) : (
              <div className="max-w-2xl mx-auto">
                {flashcards.length===0 ? <div className="text-center py-20"><div className="text-5xl mb-4">🃏</div><p className="text-zinc-400">Nenhum flashcard. Crie em Criar.</p></div> : (
                  <div className={`${bgCard} border rounded-2xl p-6`}>
                    <div className="flex justify-between items-center mb-4"><span className="text-sm text-zinc-400">Card {currentFlashIndex+1}/{flashcards.length}</span><span className="text-xs bg-violet-900/50 px-2 py-1 rounded-full">{flashcards[currentFlashIndex]?.materia} • {flashcards[currentFlashIndex]?.dificuldade} • +{flashcards[currentFlashIndex]?.xpGanho}/-{flashcards[currentFlashIndex]?.xpPerda}</span></div>
                    <h2 className="text-lg font-bold mb-6">{flashcards[currentFlashIndex]?.frente}</h2>
                    <div className="space-y-2">{flashcards[currentFlashIndex]?.alternativas?.map((alt,i)=>{const isSelected=selectedFlashAlt===i; const isCorrect=flashcards[currentFlashIndex]?.correta===i; const showResult=showFlashAnswer; let bg='bg-zinc-800 hover:bg-zinc-700 border-zinc-700'; if (showResult) { if (isCorrect) bg='bg-green-900/50 border-green-600 text-green-200'; else if (isSelected && !isCorrect) bg='bg-red-900/50 border-red-600 text-red-200'; else bg='bg-zinc-800 border-zinc-700 opacity-50' } else if (isSelected) bg='bg-violet-900/50 border-violet-600'; return <button key={i} onClick={()=>!showFlashAnswer && setSelectedFlashAlt(i)} disabled={showFlashAnswer} className={`w-full text-left border rounded-xl px-4 py-3 text-sm transition ${bg}`}>{alt}</button>})}</div>
                    {!showFlashAnswer ? <button onClick={()=>selectedFlashAlt!==null && responderFlashcard(selectedFlashAlt)} disabled={selectedFlashAlt===null} className="mt-6 w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-30 rounded-xl py-3 font-bold">Responder</button> : <div className="mt-6 space-y-4"><div className={`p-4 rounded-xl ${selectedFlashAlt===flashcards[currentFlashIndex]?.correta?'bg-green-900/30 border border-green-800':'bg-red-900/30 border border-red-800'}`}><div className="font-bold mb-1">{selectedFlashAlt===flashcards[currentFlashIndex]?.correta ? `✅ +${flashcards[currentFlashIndex]?.xpGanho} XP` : `❌ -${flashcards[currentFlashIndex]?.xpPerda} XP`}</div><div className="text-sm"><b>Correta:</b> {flashcards[currentFlashIndex]?.alternativas?.[flashcards[currentFlashIndex]?.correta||0]}</div><div className="text-sm mt-2"><b>Por que:</b> {flashcards[currentFlashIndex]?.explicacao}</div></div><button onClick={proximoFlashcard} className="w-full bg-zinc-800 hover:bg-zinc-700 rounded-xl py-3 font-bold">Próximo →</button></div>}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {view==='simulado' && (
          <div className="flex-1 overflow-y-auto p-6">
            {!simuladoAtivo ? (
              <div className="max-w-2xl mx-auto text-center py-10">
                <div className="text-5xl mb-4">📝</div><h1 className="text-3xl font-bold mb-2">Simulado ENEM</h1><p className="text-zinc-400 mb-8">Cronometrado, nota TRI, +10 XP por acerto</p>
                <div className="grid grid-cols-3 gap-3 mb-8">
                  <button onClick={()=>iniciarSimulado(10)} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 hover:border-violet-600"><div className="text-2xl font-bold">10</div><div className="text-xs text-zinc-400">Rápido (15min)</div></button>
                  <button onClick={()=>iniciarSimulado(30)} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 hover:border-blue-600"><div className="text-2xl font-bold">30</div><div className="text-xs text-zinc-400">Médio (45min)</div></button>
                  <button onClick={()=>iniciarSimulado(90)} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 hover:border-green-600"><div className="text-2xl font-bold">90</div><div className="text-xs text-zinc-400">ENEM dia (2h)</div></button>
                </div>
                <button onClick={()=>iniciarSimulado(180)} className="w-full bg-gradient-to-r from-violet-600 to-blue-600 rounded-2xl py-4 font-bold">🔥 Simulado completo 180 questões (ENEM real)</button>
                <p className="text-xs text-zinc-500 mt-4">Precisa ter {questoes.length} questões no banco. Atualmente tem {questoes.length}. Gere mais em Questões.</p>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-6 bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
                  <div><div className="font-bold">Simulado em andamento</div><div className="text-xs text-zinc-400">{Object.keys(simuladoRespostas).length}/{simuladoQuestoes.length} respondidas • {Math.floor(simuladoTime/60)}:{(simuladoTime%60).toString().padStart(2,'0')}</div></div>
                  <button onClick={finalizarSimulado} className="bg-green-600 hover:bg-green-700 px-6 py-2 rounded-xl font-bold">Finalizar</button>
                </div>
                <div className="grid gap-4">{simuladoQuestoes.map((q,idx)=><div key={q.id} className={`${bgCard} border rounded-2xl p-5 ${simuladoRespostas[q.id!]!=null?'border-violet-600/50':''}`}><div className="flex justify-between mb-3"><span className="text-xs bg-zinc-800 px-2 py-1 rounded-full">Q{idx+1} • {q.materia}</span>{simuladoRespostas[q.id!] != null && <span className="text-xs text-violet-400">Respondida</span>}</div><p className="font-medium mb-3">{q.enunciado}</p><div className="grid gap-2">{q.alternativas.map((alt,i)=><button key={i} onClick={()=>setSimuladoRespostas({...simuladoRespostas, [q.id!]: i})} className={`text-left border rounded-xl px-4 py-2 text-sm ${simuladoRespostas[q.id!]===i?'bg-violet-900/50 border-violet-600':'bg-zinc-800 border-zinc-700 hover:bg-zinc-700'}`}>{alt}</button>)}</div></div>)}</div>
              </div>
            )}
          </div>
        )}

        {view==='redacao' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl">
            <h1 className="text-2xl font-bold mb-2">✍️ Redação ENEM com correção IA C1-C5</h1><p className="text-sm text-zinc-400 mb-6">Tema, texto e correção nota 0-1000 com fallback automático</p>
            <div className="grid grid-cols-3 gap-6">
              <div className="col-span-2 space-y-4">
                <input value={redacaoTema} onChange={e=>setRedacaoTema(e.target.value)} placeholder="Tema da redação" className={`w-full ${bgInput} border rounded-xl px-4 py-3`} />
                <textarea value={redacaoTexto} onChange={e=>setRedacaoTexto(e.target.value)} placeholder="Cole sua redação aqui (mín 100 caracteres)...&#10;&#10;Dica: introdução, 2 desenvolvimentos, conclusão com proposta intervenção C5." className={`w-full ${bgInput} border rounded-xl p-4 h-96 text-sm`} />
                <div className="flex justify-between items-center"><span className="text-xs text-zinc-500">{redacaoTexto.length} caracteres • {redacaoTexto.split(/\s+/).filter(Boolean).length} palavras</span><button onClick={corrigirRedacao} disabled={isGenerating || redacaoTexto.length<100} className="bg-gradient-to-r from-green-600 to-emerald-600 px-8 py-3 rounded-xl font-bold disabled:opacity-50">{isGenerating?'Corrigindo via IA...':'✨ Corrigir com IA (C1-C5)'}</button></div>
              </div>
              <div className="space-y-4">
                <div className={`${bgCard} border rounded-2xl p-4`}><h3 className="font-bold text-sm mb-2">Como funciona</h3><p className="text-xs text-zinc-400">IA avalia C1 norma culta, C2 tema, C3 argumentos, C4 coesão, C5 proposta. Nota 0-1000. Se uma API falhar, tenta outra. Sem API, nota estimada local.</p></div>
                <div className={`${bgCard} border rounded-2xl p-4`}><h3 className="font-bold text-sm mb-3">Últimas redações ({redacoes.length})</h3><div className="space-y-2 max-h-96 overflow-y-auto">{redacoes.slice(0,5).map(r=><div key={r.id} className="bg-zinc-800 rounded-xl p-3"><div className="text-xs font-medium truncate">{r.tema}</div><div className="text-xs text-zinc-400">Nota: {r.notaTotal||'?'} • {new Date(r.createdAt).toLocaleDateString()}</div>{r.competencias && <div className="text-[10px] text-zinc-500 mt-1">C1:{r.competencias.c1} C2:{r.competencias.c2} C3:{r.competencias.c3} C4:{r.competencias.c4} C5:{r.competencias.c5}</div>}</div>)}</div></div>
              </div>
            </div>
            {redacoes[0]?.feedback && <div className={`mt-6 ${bgCard} border rounded-2xl p-6`}><h3 className="font-bold mb-2">Última correção: {redacoes[0].notaTotal} pontos</h3><div className="grid grid-cols-5 gap-2 mb-4">{redacoes[0].competencias && Object.entries(redacoes[0].competencias).map(([k,v])=><div key={k} className="bg-zinc-800 rounded-xl p-2 text-center"><div className="text-xs text-zinc-400">{k.toUpperCase()}</div><div className="font-bold">{v as number}</div></div>)}</div><p className="text-sm whitespace-pre-wrap">{redacoes[0].feedback}</p></div>}
          </div>
        )}

        {view==='pomodoro' && <div className="flex-1 flex items-center justify-center p-8"><div className="text-center max-w-md w-full"><div className="text-6xl mb-4">{pomodoroMode==='foco'?'🎯':'☕'}</div><h1 className="text-3xl font-bold mb-2">{pomodoroMode==='foco'?'Foco':'Pausa'}</h1><div className="text-7xl font-mono font-bold my-8">{Math.floor(pomodoroTime/60).toString().padStart(2,'0')}:{(pomodoroTime%60).toString().padStart(2,'0')}</div><div className="flex gap-3 justify-center"><button onClick={()=>setPomodoroActive(!pomodoroActive)} className={`px-8 py-3 rounded-full font-bold ${pomodoroActive?'bg-zinc-800':'bg-violet-600 hover:bg-violet-700'}`}>{pomodoroActive?'Pausar':'Começar'}</button><button onClick={()=>{setPomodoroActive(false); setPomodoroTime(pomodoroMode==='foco'?25*60:5*60)}} className="bg-zinc-800 px-6 py-3 rounded-full">Reset</button></div><div className="mt-8 text-sm text-zinc-400">Sessões: {pomodoroSessions} • +25 XP por foco</div></div></div>}

        {view==='estatisticas' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl">
            <h1 className="text-2xl font-bold mb-6">📈 Estatísticas Detalhadas</h1>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className={`${bgCard} border rounded-2xl p-5`}><h3 className="font-bold mb-3">Por matéria</h3>{['Biologia','Matemática','História','Química','Física','Álgebra'].map(m=>{const total=questoes.filter(q=>q.materia===m).length; const flashcardsM=flashcards.filter(f=>f.materia.toLowerCase().includes(m.toLowerCase())).length; return <div key={m} className="flex justify-between text-sm py-1 border-b border-zinc-800/50"><span>{m}</span><span className="text-zinc-400">{total} q • {flashcardsM} cards</span></div>})}</div>
              <div className={`${bgCard} border rounded-2xl p-5`}><h3 className="font-bold mb-3">Desempenho</h3><div className="text-sm space-y-2"><div>Questões totais: {questoes.length}</div><div>Flashcards: {flashcards.length} ({flashcards.filter(f=>f.acertos>0).length} dominados)</div><div>Redações: {redacoes.length}</div><div>Pomodoro: {pomodoroSessions} sessões ({Math.floor(pomodoroSessions*25/60)}h)</div><div>XP: {user?.xp} • Nível {user?.level}</div><div>Páginas dinâmicas: {dynamicPages.length}</div></div></div>
            </div>
            <div className={`${bgCard} border rounded-2xl p-5`}><h3 className="font-bold mb-2">💾 Backup e Export</h3><p className="text-xs text-zinc-400 mb-3">Seus dados ficam no IndexedDB criptografado local. Exporte para não perder.</p><div className="flex gap-2"><button onClick={()=>exportarDados('json')} className="bg-violet-600 px-4 py-2 rounded-xl text-sm">Exportar JSON completo</button><button onClick={()=>exportarDados('flashcards-pdf')} className="bg-zinc-800 px-4 py-2 rounded-xl text-sm">Exportar flashcards TXT</button></div></div>
          </div>
        )}

        {view==='questoes' && (
          <div className="flex-1 overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-6"><h1 className="text-2xl font-bold">Questões</h1><div className="flex gap-2"><input value={busca} onChange={e=>setBusca(e.target.value)} placeholder="🔍 Buscar..." className={`${bgInput} border rounded-xl px-3 py-2 text-sm w-48`} /><select value={selectedMateria} onChange={e=>setSelectedMateria(e.target.value)} className={`${bgInput} border rounded-xl px-3 py-2 text-sm`}><option>Todas</option><option>Biologia</option><option>Matemática</option><option>História</option><option>Química</option><option>Física</option><option>Álgebra</option></select><button onClick={gerarQuestao} disabled={isGenerating} className="bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-xl text-sm font-medium disabled:opacity-50">{isGenerating?'Gerando...':'✨ Gerar IA'}</button></div></div>
            <div className="grid gap-4">{filteredQuestoes.map(q=><div key={q.id} className={`${bgCard} border rounded-2xl p-5`}><div className="flex justify-between items-start mb-3"><span className="text-xs bg-zinc-800 px-2 py-1 rounded-full">{q.materia} • {q.dificuldade} • {q.fonte} {q.fonte==='ia'?'🤖':'📚'}</span><span className="text-xs text-zinc-500">{q.ano||'IA'}</span></div><p className="font-medium mb-4">{q.enunciado}</p><div className="grid gap-2">{q.alternativas.map((alt,i)=><button key={i} onClick={()=>responderQuestao(q,i)} className="text-left bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl px-4 py-3 text-sm transition">{alt}</button>)}</div></div>)}</div>
          </div>
        )}

        {view==='chat' && (
          <div className="flex-1 flex flex-col overflow-hidden bg-[#212121]">
            <div className="h-14 border-b border-zinc-800 flex items-center justify-between px-4 bg-zinc-900"><div className="flex items-center gap-3"><button onClick={criarNovoChat} className="bg-zinc-800 hover:bg-zinc-700 p-2 rounded-lg">＋</button><span className="font-medium">{chatSessions.find(s=>s.id===currentChatId)?.title||'Selecione chat'}</span></div><div className="text-xs text-zinc-500">{apiKeys.filter(k=>k.status==='ok').length} OK {apiKeys.filter(k=>k.status==='erro').length>0 && `• ${apiKeys.filter(k=>k.status==='erro').length} erro 🔴`}</div></div>
            <div className="flex flex-1 overflow-hidden"><div className="w-64 bg-[#171717] border-r border-zinc-800 p-2 overflow-y-auto hidden md:block"><button onClick={criarNovoChat} className="w-full bg-zinc-800 hover:bg-zinc-700 rounded-xl py-2.5 text-sm mb-3">+ Novo chat</button>{chatSessions.map(s=><button key={s.id} onClick={()=>setCurrentChatId(s.id!)} className={`w-full text-left px-3 py-2 rounded-xl text-sm truncate ${currentChatId===s.id?'bg-zinc-800 text-white':'text-zinc-400 hover:bg-zinc-800/50'}`}>{s.title}</button>)}</div>
            <div className="flex-1 flex flex-col">{!currentChatId ? <div className="flex-1 flex items-center justify-center p-8"><div className="text-center"><div className="text-5xl mb-4">💬</div><h2 className="text-xl font-bold mb-2">Chat super poderes</h2><button onClick={criarNovoChat} className="bg-white text-black px-6 py-2.5 rounded-full font-medium">Novo chat</button><div className="mt-8 text-xs text-zinc-500 max-w-md space-y-1"><p className="bg-zinc-800 p-2 rounded">/criar pagina biologia</p><p className="bg-zinc-800 p-2 rounded">adicione 5 flashcards de álgebra difícil +20/-5</p></div></div></div> : <><div className="flex-1 overflow-y-auto p-4 space-y-6">{chatMessages.map((m,i)=><div key={i} className={`flex gap-4 ${m.role==='user'?'justify-end':''}`}>{m.role!=='user' && <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center text-sm flex-shrink-0">AI</div>}<div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${m.role==='user'?'bg-[#2f2f2f]':'bg-transparent'}`}>{m.content}{m.providerUsed && <div className="text-[10px] text-zinc-500 mt-2">via {m.providerUsed}</div>}</div></div>)}{isGenerating && <div className="flex gap-4"><div className="w-8 h-8 rounded-full bg-zinc-800 animate-pulse"></div><div className="text-sm text-zinc-500">Gerando...</div></div>}<div ref={chatEndRef}></div></div><div className="p-4 border-t border-zinc-800"><div className="max-w-3xl mx-auto flex gap-3 bg-[#2f2f2f] rounded-full px-4 py-2"><input value={inputMsg} onChange={e=>setInputMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&enviarMensagemChat()} placeholder="Peça flashcards ou modifique site..." className="flex-1 bg-transparent outline-none text-sm placeholder:text-zinc-500" /><button onClick={enviarMensagemChat} disabled={isGenerating} className="bg-white text-black rounded-full w-8 h-8 flex items-center justify-center disabled:opacity-50">↑</button></div></div></>}</div></div>
          </div>
        )}

        {view==='settings' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl">
            <h1 className="text-2xl font-bold mb-2">⚙️ Central de APIs</h1><p className="text-sm text-zinc-400 mb-6">Fallback automático com bolinha vermelha se falhar.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6"><div className="md:col-span-2 bg-zinc-900 border border-zinc-800 rounded-2xl p-5"><h3 className="font-bold mb-4">Adicionar API</h3><div className="space-y-3"><select value={settingsForm.provider} onChange={e=>setSettingsForm({...settingsForm, provider: e.target.value as any})} className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2.5"><option value="openai">OpenAI</option><option value="gemini">Gemini</option><option value="groq">Groq (grátis rápido)</option><option value="anthropic">Claude</option><option value="tavily">Tavily (busca)</option><option value="openrouter">OpenRouter</option></select><input value={settingsForm.key} onChange={e=>setSettingsForm({...settingsForm, key:e.target.value})} placeholder="Cole API key" type="password" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2.5" /><input value={settingsForm.model} onChange={e=>setSettingsForm({...settingsForm, model:e.target.value})} placeholder="Modelo (opcional)" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2.5 text-sm" /><textarea value={settingsForm.personalidade} onChange={e=>setSettingsForm({...settingsForm, personalidade:e.target.value})} placeholder="Personalidade da IA" className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2.5 text-sm h-24" /><button onClick={salvarApiKey} className="w-full bg-violet-600 hover:bg-violet-700 rounded-xl py-2.5 font-medium">🔒 Salvar criptografado</button></div></div><div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5"><h3 className="font-bold mb-3 text-sm">Chaves grátis:</h3><div className="space-y-2 text-xs text-zinc-400"><p><b className="text-white">Groq:</b> console.groq.com</p><p><b className="text-white">Gemini:</b> aistudio.google.com</p><p><b className="text-white">Tavily:</b> tavily.com (500 free)</p></div></div></div>
            <div className="mt-6 bg-zinc-900 border border-zinc-800 rounded-2xl p-5"><h3 className="font-bold mb-4">APIs ({apiKeys.length})</h3><div className="space-y-2">{apiKeys.map(k=>{const cfg=getProviderConfig(k.provider); return <div key={k.id} className="flex items-center justify-between bg-zinc-800 rounded-xl px-4 py-3"><div className="flex items-center gap-3"><div className={`w-2.5 h-2.5 rounded-full ${k.status==='ok'?'bg-green-500':k.status==='erro'?'bg-red-500 animate-pulse':k.status==='testando'?'bg-yellow-500 animate-pulse':'bg-zinc-500'}`}></div><div><div className="text-sm font-medium flex items-center gap-2">{cfg.name} <span className="text-xs text-zinc-500">{k.model}</span> {k.status==='erro' && <span className="text-xs bg-red-900/50 text-red-400 px-2 py-0.5 rounded-full">🔴</span>}</div></div></div><div className="flex gap-2"><button onClick={()=>testarKey(k)} className="text-xs bg-zinc-700 hover:bg-zinc-600 px-3 py-1.5 rounded-lg">Testar</button><button onClick={()=>deletarKey(k.id!)} className="text-xs bg-red-900/30 hover:bg-red-900/50 text-red-400 px-3 py-1.5 rounded-lg">Excluir</button></div></div>})}{apiKeys.length===0 && <div className="text-sm text-zinc-500 text-center py-6">Nenhuma API</div>}</div></div>
          </div>
        )}

        {view==='ranking' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-3xl">
            <h1 className="text-2xl font-bold mb-6">🏆 Ranking & Conquistas</h1>
            <div className={`${bgCard} border rounded-2xl p-6 mb-6`}><h3 className="font-bold mb-4">Seu progresso</h3><div className="flex items-center gap-4"><div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center text-2xl">{user?.name?.[0]}</div><div><div className="font-bold">{user?.name} - Nível {user?.level}</div><div className="text-sm text-zinc-400">{user?.xp} XP • {flashcards.length} flashcards • {questoes.length} questões • {redacoes.length} redações</div></div></div></div>
            <div className={`${bgCard} border rounded-2xl p-6`}><h3 className="font-bold mb-4">Conquistas ({conquistas.length})</h3><div className="grid gap-3">{conquistas.map(c=><div key={c.id} className="bg-zinc-800 rounded-xl p-3 flex items-center gap-3"><span className="text-2xl">{c.icon}</span><div><div className="text-sm font-medium">{c.titulo}</div><div className="text-xs text-zinc-400">{c.descricao} • +{c.xp} XP</div></div></div>)}{conquistas.length===0 && <div className="text-sm text-zinc-500">Nenhuma ainda. Estude!</div>}</div></div>
          </div>
        )}

        {view==='dynamic' && <div className="flex-1 overflow-y-auto p-6"><h1 className="text-2xl font-bold mb-6">📚 Páginas Dinâmicas</h1><div className="grid gap-4">{dynamicPages.map(p=><div key={p.id} className={`${bgCard} border rounded-2xl p-5`}><div className="flex items-center gap-3 mb-2"><span className="text-2xl">{p.icon}</span><span className="font-bold">{p.title}</span><span className="text-xs bg-zinc-800 px-2 py-1 rounded-full">{p.materia}</span></div><p className="text-sm text-zinc-400">{p.content}</p></div>)}</div></div>}
      </div>
    </div>
  )
}
