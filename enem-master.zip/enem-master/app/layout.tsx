import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ENEM Master - Offline Total com IA',
  description: 'Plataforma completa ENEM 100% offline. Flashcards customizáveis, simulados, redação IA, XP, pomodoro e auto-modificação em tempo real.',
  manifest: '/manifest.json',
  themeColor: '#7c3aed',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'ENEM Master'
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#7c3aed" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="ENEM Master" />
        <link rel="apple-touch-icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>" />
      </head>
      <body className="min-h-screen bg-[#0f0f0f] text-white antialiased">
        {children}
        <script dangerouslySetInnerHTML={{__html: `
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js')
                .then(reg => console.log('[PWA] SW registrado:', reg.scope))
                .catch(err => console.log('[PWA] SW falhou:', err))
            })
          }
          // Detecta instalação PWA
          let deferredPrompt;
          window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            console.log('[PWA] Pode instalar');
            // Mostra botão de instalar se existir
            const btn = document.getElementById('pwa-install-btn');
            if (btn) btn.style.display = 'block';
          });
        `}} />
      </body>
    </html>
  )
}
