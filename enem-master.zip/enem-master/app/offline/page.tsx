'use client'
export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center p-8">
      <div className="text-center max-w-md">
        <div className="text-6xl mb-4">📴</div>
        <h1 className="text-2xl font-bold mb-2">Você está offline</h1>
        <p className="text-zinc-400 mb-6">Mas o ENEM Master funciona 100% offline! Seu banco de dados está no seu dispositivo.</p>
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-left text-sm">
          <p className="font-bold mb-2">✅ O que funciona offline:</p>
          <ul className="space-y-1 text-zinc-400">
            <li>• Login e cadastro (local criptografado)</li>
            <li>• Todas as questões salvas</li>
            <li>• Flashcards e revisão espaçada</li>
            <li>• Simulado cronometrado</li>
            <li>• Pomodoro e XP</li>
            <li>• Páginas dinâmicas criadas</li>
            <li>• Chat com respostas locais</li>
          </ul>
          <p className="font-bold mt-4 mb-2">❌ Precisa internet:</p>
          <ul className="space-y-1 text-zinc-400">
            <li>• Gerar novas questões via IA</li>
            <li>• Corrigir redação com IA</li>
            <li>• Buscar questões reais (Tavily)</li>
            <li>• Chat com IA real</li>
          </ul>
        </div>
        <button onClick={()=>window.location.href='/'} className="mt-6 bg-violet-600 px-6 py-3 rounded-xl font-bold">Voltar ao app</button>
      </div>
    </div>
  )
}
