# Prompt para IA do GitHub (Copilot Workspace / Chat)

Copie e cole isso na IA do GitHub quando criar o repositório:

---

**Crie um repositório chamado enem-master com o seguinte projeto:**

É um site de estudos ENEM completo, 100% offline PWA, com:

- Next.js 14 App Router, TypeScript, Tailwind, Dexie (IndexedDB)
- Funcionalidades: login local criptografado AES-GCM, questões, flashcards customizáveis por prompt natural ("Faça perguntas sobre história difícil 5 alternativas +20/-5 XP com porquê"), simulado 10-180q cronometrado, redação IA C1-C5, chat idêntico ChatGPT com comandos de auto-modificação em tempo real (/criar pagina biologia), pomodoro com XP, ranking, conquistas, estatísticas, export JSON/TXT, tema claro/escuro, sistema offline total com Service Worker

**Estrutura:**
- app/page.tsx = app principal com todas as views (dashboard, questoes, flashcards, simulado, redacao, pomodoro, ranking, chat, settings, estatisticas)
- app/layout.tsx = layout com manifest e registro SW
- app/offline/page.tsx = página offline
- lib/db.ts = Dexie DB com tabelas users, questoes, flashcards, redacoes, simulados, etc
- lib/crypto.ts = criptografia AES-GCM e hash senha
- lib/apiManager.ts = fallback automático entre OpenAI, Gemini, Groq, Claude, Tavily, OpenRouter, geração flashcards e correção redação
- public/manifest.json = PWA manifest instalável
- public/sw.js = Service Worker cache-first offline total
- README.md = documentação completa
- package.json, tailwind.config.js, etc

**Requisitos:**
- Deploy grátis Vercel Hobby (100GB banda, 1M functions)
- 100% local-first, sem backend obrigatório, chaves API criptografadas no dispositivo
- Se uma API falhar, troca automaticamente e mostra bolinha vermelha 🔴 em Configurações, sem erro pro usuário

**Instruções deploy:**
npm install && npm run dev (localhost:3000)
Para Vercel: conectar GitHub repo e dar import, sem env obrigatório

O código completo está no arquivo enem-master.zip anexado. Extraia e faça push.

---
