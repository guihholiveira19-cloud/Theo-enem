# 🎓 ENEM Master v4 - Site de Estudos Offline Total com IA Auto-Modificável

Plataforma completa de estudos para ENEM e vestibulares que funciona **100% offline** como PWA instalável, com sistema de flashcards customizável por prompt, simulados, correção de redação IA, XP, pomodoro e modificação do site em tempo real.

**Criado para ser hospedado 100% grátis no Vercel Hobby + Supabase Free**

## 🚀 Funcionalidades

### 📴 Sistema Offline Total (PWA)
- ✅ Service Worker com cache total - funciona sem internet após primeira visita
- ✅ Instalável como app (Android, iPhone, PC) - ícone na tela inicial
- ✅ Banco IndexedDB criptografado AES-GCM no dispositivo - sem risco
- ✅ Indicador online/offline + página offline dedicada
- ✅ Sync automático quando volta online

### 🃏 Flashcards Inteligentes Customizáveis
- Usuário digita em linguagem natural como quer:
  > "Faça perguntas sobre história, de modo bem difícil, bote 5 alternativas, se eu acertar me dê 20 xp, se errar perca 5 xp, e me dê a resposta e o porquê"
- IA extrai matéria, dificuldade, nº alternativas, XP ganho/perda, explicação
- Gera 5 flashcards seguindo EXATO
- Modo estudo com revisão espaçada (Anki): acerto = 1 dia, erro = 10 min
- XP com perda configurável + animação

### 📝 Questões
- Banco local com questões ENEM reais + geradas por IA
- Filtro por matéria, busca em tempo real
- Geração via IA com fallback automático entre APIs
- Busca questões reais via Tavily API

### 📝 Simulado ENEM
- 10, 30, 90 ou 180 questões (ENEM completo)
- Cronometrado, nota TRI 0-1000, tempo total
- +10 XP por acerto

### ✍️ Redação IA C1-C5
- Tema + texto → correção nas 5 competências ENEM
- Nota 0-1000, feedback detalhado, sugestão de melhoria
- Fallback automático se API falhar

### 💬 Chat IA idêntico ChatGPT com Auto-Modificação
- UI idêntica ChatGPT (sidebar, streaming, histórico)
- Comandos especiais em tempo real:
  - `/criar pagina biologia sobre DNA` → cria página na hora no menu
  - `adicione 5 flashcards de álgebra difícil +20/-5` → vai pra flashcards
  - `mude a cor do site para azul`
- Personalidade configurável por API

### 🔑 Central de APIs com Fallback Automático
- Cadastre OpenAI, Gemini, Groq (grátis rápido), Claude, Tavily, OpenRouter
- Diga tipo, cole chave, escolha modelo e personalidade
- Teste automático com bolinha: 🟢 OK, 🔴 Erro, 🟡 Testando
- Se uma falhar, troca automaticamente pra melhor disponível sem mostrar erro pro usuário

### 🍅 Pomodoro + Gamificação
- 25min foco / 5min pausa, +25 XP por sessão
- XP total, nível (XP/100), streak, conquistas
- Conquistas: 100 XP 🔥, Mestre Flashcards 🃏, Foco Total 🍅, etc
- Ranking local

### 📊 Estatísticas + Export
- Por matéria, desempenho, horas focadas
- Export JSON completo + flashcards TXT
- Tema claro/escuro ☀️🌙

## 🛠️ Tecnologias
- Next.js 14 (App Router)
- Dexie (IndexedDB)
- Web Crypto API (AES-GCM)
- Tailwind CSS
- PWA com Service Worker

## 📦 Como rodar local
```bash
npm install
npm run dev
# http://localhost:3000
```

## 🌐 Deploy Grátis Vercel Hobby (Recomendado)

### Vercel é 100% grátis para projeto pessoal:
- 100GB banda/mês, 1M functions, domínio custom grátis
- **Atenção:** Hobby é proibido uso comercial. Se for cobrar, use Pro $20/mês

**Passo a passo:**
1. Crie conta no github.com
2. Crie novo repositório e faça push deste projeto:
```bash
git init
git add .
git commit -m "ENEM Master v4 offline"
git branch -M main
git remote add origin https://github.com/SEUUSER/enem-master.git
git push -u origin main
```
3. Crie conta no vercel.com → Continue with GitHub → Import Project → selecione repo
4. Em Settings → Environment Variables adicione suas chaves (opcional, pois app já funciona com chaves locais):
```
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=...
```
5. Deploy → seu site em `seu-projeto.vercel.app` com PWA offline!

## 🔑 Como pegar APIs grátis
- **Groq (recomendado, grátis e ultra rápido):** console.groq.com → API Keys
- **Gemini (grátis):** aistudio.google.com → Get API Key
- **Tavily (busca real, 500/mês grátis):** tavily.com
- **OpenAI:** platform.openai.com

## 📴 Como instalar como app offline
1. Abra o site no celular
2. Banner roxo "Instalar app" aparece → clique
3. Android: Menu ⋮ → Instalar app
4. iPhone: Compartilhar → Adicionar à Tela de Início
5. Desligue Wi-Fi e abra o app → funciona 100%!

## 📄 Licença
MIT - Use livremente para estudos

## 🙏 Créditos
Criado com IA para ser o melhor site de estudos gratuito, offline e auto-modificável do Brasil.
