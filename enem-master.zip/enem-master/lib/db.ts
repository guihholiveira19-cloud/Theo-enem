import Dexie, { Table } from 'dexie'

export interface User {
  id?: number
  email: string
  name: string
  passwordHash: string
  salt: string
  createdAt: number
  xp: number
  level: number
  streak: number
  lastStudy: number
  avatar?: string
}

export interface Questao {
  id?: number
  enunciado: string
  alternativas: string[]
  correta: number
  materia: string
  dificuldade: 'facil' | 'medio' | 'dificil'
  fonte: 'ia' | 'enem' | 'vestibular' | 'tavily'
  explicacao?: string
  ano?: number
  createdAt: number
}

export interface Progresso {
  id?: number
  userId: number
  questaoId: number
  acertou: boolean
  tempo: number
  timestamp: number
  xpGanho: number
}

export interface ApiKey {
  id?: number
  provider: 'openai' | 'gemini' | 'anthropic' | 'tavily' | 'groq' | 'openrouter'
  keyEncrypted: string
  model: string
  personalidade?: string
  ativo: boolean
  status: 'ok' | 'erro' | 'testando' | 'nao_testado'
  lastTest?: number
  prioridade: number // menor = tenta primeiro
}

export interface ChatMessage {
  id?: number
  chatId: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: number
  providerUsed?: string
  modelUsed?: string
}

export interface ChatSession {
  id?: string
  title: string
  createdAt: number
  updatedAt: number
  personalidade?: string
}

export interface DynamicPage {
  id?: number
  slug: string
  title: string
  materia: string
  content: string // JSON ou markdown
  icon: string
  createdAt: number
  createdBy: 'user' | 'ia'
}

export interface Flashcard {
  id?: number
  frente: string // pergunta
  verso: string // resposta curta
  alternativas?: string[] // se tiver alternativas
  correta?: number // índice da correta
  explicacao: string // por que é correta
  materia: string
  dificuldade: 'facil' | 'medio' | 'dificil' | 'muito-dificil'
  xpGanho: number
  xpPerda: number
  instrucaoOriginal: string // o que usuário pediu
  acertos: number
  erros: number
  proximaRevisao: number // timestamp para repetição espaçada
  createdAt: number
}

export interface Conquista {
  id?: number
  userId: number
  titulo: string
  descricao: string
  icon: string
  xp: number
  timestamp: number
}

export interface Redacao {
  id?: number
  userId?: number
  tema: string
  texto: string
  notaTotal?: number
  competencias?: { c1: number, c2: number, c3: number, c4: number, c5: number }
  feedback?: string
  createdAt: number
}

export interface Simulado {
  id?: number
  userId?: number
  questoesIds: number[]
  respostas: { questaoId: number, alternativa: number, tempo: number }[]
  nota?: number
  tempoTotal: number
  finalizado: boolean
  createdAt: number
}

export class EnemDB extends Dexie {
  users!: Table<User>
  questoes!: Table<Questao>
  progressos!: Table<Progresso>
  apikeys!: Table<ApiKey>
  chatMessages!: Table<ChatMessage>
  chatSessions!: Table<ChatSession>
  dynamicPages!: Table<DynamicPage>
  flashcards!: Table<Flashcard>
  conquistas!: Table<Conquista>
  redacoes!: Table<Redacao>
  simulados!: Table<Simulado>

  constructor() {
    super('EnemMasterDB')
    this.version(1).stores({
      users: '++id, email',
      questoes: '++id, materia, fonte, dificuldade',
      progressos: '++id, userId, questaoId, timestamp',
      apikeys: '++id, provider',
      chatMessages: '++id, chatId, timestamp',
      chatSessions: 'id, createdAt',
      dynamicPages: '++id, slug, materia'
    })
    this.version(2).stores({
      users: '++id, email',
      questoes: '++id, materia, fonte, dificuldade',
      progressos: '++id, userId, questaoId, timestamp',
      apikeys: '++id, provider',
      chatMessages: '++id, chatId, timestamp',
      chatSessions: 'id, createdAt',
      dynamicPages: '++id, slug, materia',
      flashcards: '++id, materia, dificuldade, proximaRevisao',
      conquistas: '++id, userId, timestamp'
    }).upgrade(tx => {
      console.log('Upgrading to v2 - flashcards')
    })
    this.version(3).stores({
      users: '++id, email',
      questoes: '++id, materia, fonte, dificuldade',
      progressos: '++id, userId, questaoId, timestamp',
      apikeys: '++id, provider',
      chatMessages: '++id, chatId, timestamp',
      chatSessions: 'id, createdAt',
      dynamicPages: '++id, slug, materia',
      flashcards: '++id, materia, dificuldade, proximaRevisao',
      conquistas: '++id, userId, timestamp',
      redacoes: '++id, userId, createdAt',
      simulados: '++id, userId, createdAt'
    }).upgrade(tx => {
      console.log('Upgrading to v3 - redacoes e simulados')
    })
  }
}

export const db = new EnemDB()

// Inicializa dados padrão
export async function initDefaultData() {
  const count = await db.questoes.count()
  if (count === 0) {
    await db.questoes.bulkAdd([
      {
        enunciado: "Qual é a principal função da mitocôndria?",
        alternativas: ["Fotossíntese", "Respiração celular e produção de ATP", "Síntese de proteínas", "Digestão celular"],
        correta: 1,
        materia: "Biologia",
        dificuldade: "facil",
        fonte: "enem",
        explicacao: "Mitocôndria é a usina de energia da célula, produz ATP na respiração celular.",
        ano: 2022,
        createdAt: Date.now()
      },
      {
        enunciado: "Em uma PA, a1=3 e r=5. Qual é o a10?",
        alternativas: ["43", "48", "53", "58"],
        correta: 1,
        materia: "Matemática",
        dificuldade: "medio",
        fonte: "enem",
        explicacao: "an = a1 + (n-1)*r => a10 = 3 + 9*5 = 48",
        ano: 2021,
        createdAt: Date.now()
      },
      {
        enunciado: "A Revolução Francesa começou em:",
        alternativas: ["1776", "1789", "1792", "1804"],
        correta: 1,
        materia: "História",
        dificuldade: "facil",
        fonte: "enem",
        explicacao: "Queda da Bastilha em 14 de julho de 1789 marca o início.",
        ano: 2020,
        createdAt: Date.now()
      }
    ])
  }

  const pages = await db.dynamicPages.count()
  if (pages === 0) {
    await db.dynamicPages.bulkAdd([
      { slug: "biologia", title: "Biologia", materia: "Biologia", content: "Estude célula, genética, ecologia", icon: "🧬", createdAt: Date.now(), createdBy: "ia" },
      { slug: "matematica", title: "Matemática", materia: "Matemática", content: "Funções, geometria, PA/PG", icon: "📐", createdAt: Date.now(), createdBy: "ia" },
      { slug: "historia", title: "História", materia: "História", content: "Brasil, Geral, Atualidades", icon: "📜", createdAt: Date.now(), createdBy: "ia" },
    ])
  }
}
