// Crypto local seguro - armazena no dispositivo criptografado
// Usa Web Crypto API + senha derivada do próprio dispositivo

const ENCRYPTION_KEY_SALT = 'enem-master-salt-v1'

async function getKeyFromPassword(password: string): Promise<CryptoKey> {
  const enc = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  )
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: enc.encode(ENCRYPTION_KEY_SALT),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  )
}

export async function encryptData(data: string, deviceId: string): Promise<string> {
  const key = await getKeyFromPassword(deviceId)
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const enc = new TextEncoder()
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    enc.encode(data)
  )
  const combined = new Uint8Array(iv.length + encrypted.byteLength)
  combined.set(iv)
  combined.set(new Uint8Array(encrypted), iv.length)
  return btoa(String.fromCharCode(...combined))
}

export async function decryptData(encryptedBase64: string, deviceId: string): Promise<string> {
  try {
    const key = await getKeyFromPassword(deviceId)
    const combined = Uint8Array.from(atob(encryptedBase64), c => c.charCodeAt(0))
    const iv = combined.slice(0, 12)
    const data = combined.slice(12)
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    )
    return new TextDecoder().decode(decrypted)
  } catch {
    return ''
  }
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder()
  const data = enc.encode(password + salt)
  const hash = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2,'0')).join('')
}

export function generateDeviceId(): string {
  if (typeof window === 'undefined') return 'server'
  let id = localStorage.getItem('enem_device_id')
  if (!id) {
    id = 'dev_' + Math.random().toString(36).substring(2,15) + Date.now().toString(36)
    localStorage.setItem('enem_device_id', id)
  }
  return id
}

export function generateSalt(): string {
  return Math.random().toString(36).substring(2,15) + Math.random().toString(36).substring(2,15)
}
