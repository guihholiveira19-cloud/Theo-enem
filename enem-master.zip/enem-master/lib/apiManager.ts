import { db, ApiKey } from './db'
import { decryptData, generateDeviceId } from './crypto'

export type Provider = ApiKey['provider']

interface ApiCallResult {
  success: boolean
  data?: any
  error?: string
  providerUsed: Provider
  modelUsed: string
}

const PROVIDER_CONFIG = {
  openai: {
    name: 'OpenAI',
    models: ['gpt-4o-mini', 'gpt-4o', 'gpt-4-turbo', 'gpt-3.5-turbo'],
    endpoint: 'https://api.openai.com/v1/chat/completions',
    color: 'bg-green-500'
  },
  gemini: {
    name: 'Google Gemini',
    models: ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-pro'],
    endpoint: 'https://generativelanguage.googleapis.com/v1beta/models',
    color: 'bg-blue-500'
  },
  anthropic: {
    name: 'Anthropic Claude',
    models: ['claude-3-haiku-20240307', 'claude-3-sonnet-20240229', 'claude-3-opus-20240229'],
    endpoint: 'https://api.anthropic.com/v1/messages',
    color: 'bg-orange-500'
  },
  groq: {
    name: 'Groq (ultra rápido)',
    models: ['llama3-8b-8192', 'llama3-70b-8192', 'mixtral-8x7b-32768'],
    endpoint: 'https://api.groq.com/openai/v1/chat/completions',
    color: 'bg-purple-500'
  },
  tavily: {
    name: 'Tavily (busca real)',
    models: ['tavily-search'],
    endpoint: 'https://api.tavily.com/search',
    color: 'bg-yellow-500'
  },
  openrouter: {
    name: 'OpenRouter',
    models: ['openai/gpt-4o-mini', 'google/gemini-flash-1.5', 'anthropic/claude-3-haiku'],
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
    color: 'bg-pink-500'
  }
}

export function getProviderConfig(provider: Provider) {
  return PROVIDER_CONFIG[provider]
}

export async function getDecryptedKey(apiKey: ApiKey): Promise<string> {
  const deviceId = generateDeviceId()
  return await decryptData(apiKey.keyEncrypted, deviceId)
}

// Testa uma API
export async function testApiKey(apiKey: ApiKey): Promise<boolean> {
  try {
    const key = await getDecryptedKey(apiKey)
    if (!key) return false

    if (apiKey.provider === 'tavily') {
      const res = await fetch('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: key, query: 'ENEM', max_results: 1 })
      })
      return res.ok
    }

    if (apiKey.provider === 'gemini') {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${key}`)
      return res.ok
    }

    if (apiKey.provider === 'openai' || apiKey.provider === 'groq' || apiKey.provider === 'openrouter') {
      const endpoint = PROVIDER_CONFIG[apiKey.provider].endpoint
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${key}`
        },
        body: JSON.stringify({
          model: apiKey.model,
          messages: [{ role: 'user', content: 'Hi' }],
          max_tokens: 5
        })
      })
      return res.ok || res.status === 400 // 400 pode ser só falta de créditos, mas key válida
    }

    return false
  } catch {
    return false
  }
}

// Chama IA com fallback automático
export async function callAIWithFallback(
  messages: { role: string, content: string }[],
  task: 'chat' | 'questoes' | 'busca' = 'chat'
): Promise<ApiCallResult> {
  const allKeys = await db.apikeys.where('ativo').equals(1).toArray()
  // Ordena por prioridade
  const sorted = allKeys.sort((a,b) => a.prioridade - b.prioridade)

  // Filtra por tarefa
  let candidates = sorted
  if (task === 'busca') {
    candidates = sorted.filter(k => k.provider === 'tavily')
    if (candidates.length === 0) candidates = sorted // fallback pra qualquer
  } else {
    candidates = sorted.filter(k => k.provider !== 'tavily')
  }

  if (candidates.length === 0) {
    return { success: false, error: 'Nenhuma API configurada', providerUsed: 'openai', modelUsed: '' }
  }

  for (const apiKey of candidates) {
    try {
      const key = await getDecryptedKey(apiKey)
      if (!key) continue

      let result
      if (apiKey.provider === 'gemini') {
        result = await callGemini(key, apiKey.model, messages)
      } else if (apiKey.provider === 'tavily') {
        continue // Tavily não faz chat
      } else {
        result = await callOpenAICompatible(key, apiKey, messages)
      }

      if (result.success) {
        // Marca como OK
        await db.apikeys.update(apiKey.id!, { status: 'ok', lastTest: Date.now() })
        return result
      } else {
        // Marca erro mas tenta próxima
        await db.apikeys.update(apiKey.id!, { status: 'erro', lastTest: Date.now() })
        console.warn(`API ${apiKey.provider} falhou, tentando próxima...`)
      }
    } catch (e) {
      await db.apikeys.update(apiKey.id!, { status: 'erro', lastTest: Date.now() })
    }
  }

  return { success: false, error: 'Todas as APIs falharam', providerUsed: 'openai', modelUsed: '' }
}

async function callOpenAICompatible(key: string, apiKey: ApiKey, messages: any[]): Promise<ApiCallResult> {
  const config = PROVIDER_CONFIG[apiKey.provider]
  const res = await fetch(config.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${key}`
    },
    body: JSON.stringify({
      model: apiKey.model,
      messages,
      max_tokens: 1000,
      temperature: 0.7
    })
  })

  if (!res.ok) {
    const err = await res.text()
    return { success: false, error: err, providerUsed: apiKey.provider, modelUsed: apiKey.model }
  }

  const data = await res.json()
  const content = data.choices?.[0]?.message?.content || data.choices?.[0]?.text || JSON.stringify(data)
  
  return { success: true, data: content, providerUsed: apiKey.provider, modelUsed: apiKey.model }
}

async function callGemini(key: string, model: string, messages: any[]): Promise<ApiCallResult> {
  // Converte messages para formato Gemini
  const contents = messages.filter(m => m.role !== 'system').map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }))

  const systemInstruction = messages.find(m => m.role === 'system')?.content

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`
  
  const body: any = { contents }
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] }
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })

  if (!res.ok) {
    return { success: false, error: await res.text(), providerUsed: 'gemini', modelUsed: model }
  }

  const data = await res.json()
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text || ''

  return { success: true, data: content, providerUsed: 'gemini', modelUsed: model }
}

// Busca questões reais via Tavily
export async function buscarQuestoesReais(query: string): Promise<ApiCallResult> {
  const tavilyKeys = await db.apikeys.where('provider').equals('tavily').toArray()
  if (tavilyKeys.length === 0) {
    return { success: false, error: 'Tavily não configurado', providerUsed: 'tavily', modelUsed: 'tavily-search' }
  }

  for (const apiKey of tavilyKeys) {
    try {
      const key = await getDecryptedKey(apiKey)
      const res = await fetch('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          api_key: key,
          query: `${query} ENEM vestibular questão prova`,
          search_depth: 'advanced',
          max_results: 5,
          include_answer: true
        })
      })

      if (res.ok) {
        const data = await res.json()
        await db.apikeys.update(apiKey.id!, { status: 'ok', lastTest: Date.now() })
        return { success: true, data: data.results, providerUsed: 'tavily', modelUsed: 'tavily-search' }
      } else {
        await db.apikeys.update(apiKey.id!, { status: 'erro', lastTest: Date.now() })
      }
    } catch {}
  }

  return { success: false, error: 'Busca falhou', providerUsed: 'tavily', modelUsed: 'tavily-search' }
}

// Gera questão via IA
export async function gerarQuestaoIA(materia: string, dificuldade: string): Promise<ApiCallResult> {
  const prompt = `Crie 1 questão de ${materia} nível ${dificuldade} no estilo ENEM.
  Retorne APENAS JSON válido no formato:
  {
    "enunciado": "...",
    "alternativas": ["A) ...", "B) ...", "C) ...", "D) ...", "E) ..."],
    "correta": 2,
    "explicacao": "..."
  }
  Correta é índice 0-4.`

  const result = await callAIWithFallback([
    { role: 'system', content: 'Você é um professor especialista em criar questões ENEM. Retorne apenas JSON válido.' },
    { role: 'user', content: prompt }
  ], 'questoes')

  if (result.success) {
    try {
      // Tenta extrair JSON
      const jsonMatch = result.data.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0])
        return { ...result, data: parsed }
      }
    } catch {}
  }

  return result
}

// Corrige redação ENEM C1-C5
export async function corrigirRedacaoIA(tema: string, texto: string): Promise<ApiCallResult> {
  const prompt = `Você é corretor oficial ENEM. Corrija a redação abaixo com tema "${tema}".

TEXTO:
${texto}

Avalie nas 5 competências ENEM (0-200 cada):
C1 - Norma culta
C2 - Compreensão tema e gênero dissertativo-argumentativo
C3 - Seleção e organização de argumentos
C4 - Coesão
C5 - Proposta intervenção

Retorne APENAS JSON válido:
{
  "notaTotal": 880,
  "competencias": { "c1": 160, "c2": 200, "c3": 180, "c4": 180, "c5": 160 },
  "feedback": "Feedback detalhado por competência, elogiando e apontando melhorias...",
  "sugestao": "Versão melhorada de um parágrafo..."
}`

  const result = await callAIWithFallback([
    { role: 'system', content: 'Você é corretor ENEM experiente, rigoroso mas motivador. Retorne apenas JSON válido.' },
    { role: 'user', content: prompt }
  ], 'questoes')

  if (result.success) {
    try {
      const jsonMatch = result.data.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0])
        return { ...result, data: parsed }
      }
    } catch {}
  }
  return result
}

// Gera simulado completo
export async function gerarSimuladoIA(qtd: number, materias: string[]): Promise<ApiCallResult> {
  const prompt = `Crie ${qtd} questões ENEM balanceadas entre ${materias.join(', ')}.
  Retorne JSON array com formato: [{"enunciado":"...","alternativas":["A) ...",...],"correta":0,"materia":"...","dificuldade":"medio","explicacao":"..."}]`

  return await callAIWithFallback([
    { role: 'system', content: 'Você cria simulados ENEM. Retorne apenas JSON array.' },
    { role: 'user', content: prompt }
  ], 'questoes')
}

// Gera flashcards via IA com instrução customizada do usuário
export async function gerarFlashcardsIA(instrucaoUsuario: string): Promise<ApiCallResult> {
  const prompt = `O usuário quer flashcards com a seguinte instrução DETALHADA:

"${instrucaoUsuario}"

Você deve criar 5 flashcards seguindo EXATAMENTE o que ele pediu.
Analise a instrução para extrair:
- Matéria (história, álgebra, biologia, etc)
- Dificuldade (fácil, médio, difícil, muito difícil)
- Quantas alternativas (se não disser, use 4)
- Quanto XP ganha se acertar e perde se errar (se não disser, use +15/-5)
- Se quer explicação após responder

Retorne APENAS JSON válido no formato ARRAY:
[
  {
    "frente": "Pergunta aqui",
    "verso": "Resposta curta aqui",
    "alternativas": ["A) ...", "B) ...", "C) ...", "D) ...", "E) ..."],
    "correta": 2,
    "explicacao": "Explicação detalhada do por que essa é a correta...",
    "materia": "História",
    "dificuldade": "dificil",
    "xpGanho": 20,
    "xpPerda": 5
  }
]

REGRAS CRÍTICAS:
- Se usuário disser "5 alternativas", crie 5
- Se disser "perca xp", use xpPerda >0
- Se disser "muito difícil", faça perguntas realmente difíceis nível ITA/IME
- Sempre inclua explicação do porquê é correta
- frente = pergunta, verso = resposta resumida
- correta = índice 0-4`

  const result = await callAIWithFallback([
    { role: 'system', content: 'Você é um criador de flashcards especialista. Você segue EXATAMENTE as instruções do usuário sobre dificuldade, alternativas, XP e explicação. Retorne apenas JSON array válido, sem texto extra.' },
    { role: 'user', content: prompt }
  ], 'questoes')

  if (result.success) {
    try {
      const jsonMatch = result.data.match(/\[[\s\S]*\]/)
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0])
        return { ...result, data: parsed }
      }
    } catch (e) {
      console.error('Erro parse flashcards', e)
    }
  }

  return result
}
