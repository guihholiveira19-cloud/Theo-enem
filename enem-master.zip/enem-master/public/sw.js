// ENEM Master - Service Worker Offline Total
const CACHE_NAME = 'enem-master-v3-offline'
const OFFLINE_URL = '/'

// Arquivos essenciais para cache
const PRECACHE_URLS = [
  '/',
  '/manifest.json'
]

self.addEventListener('install', (event) => {
  console.log('[SW] Install - cacheando arquivos essenciais')
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(PRECACHE_URLS)
    }).then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', (event) => {
  console.log('[SW] Activate - limpando caches antigos')
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('[SW] Deletando cache antigo:', cacheName)
            return caches.delete(cacheName)
          }
        })
      )
    }).then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  // Ignora requisições de APIs externas (OpenAI, Gemini, etc) - deixa tentar rede, se falhar usa fallback local
  const url = new URL(event.request.url)
  if (
    url.hostname.includes('openai.com') ||
    url.hostname.includes('googleapis.com') ||
    url.hostname.includes('anthropic.com') ||
    url.hostname.includes('groq.com') ||
    url.hostname.includes('tavily.com') ||
    url.hostname.includes('openrouter.ai')
  ) {
    // Network first para APIs, se offline retorna erro que nosso fallback já trata
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(JSON.stringify({ error: 'offline', offline: true }), {
          headers: { 'Content-Type': 'application/json' },
          status: 503
        })
      })
    )
    return
  }

  // Para tudo que é do nosso site: Cache First, Network Fallback
  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      if (cachedResponse) {
        // Tem no cache, retorna e atualiza em background
        event.waitUntil(
          fetch(event.request).then(networkResponse => {
            if (networkResponse.ok) {
              caches.open(CACHE_NAME).then(cache => cache.put(event.request, networkResponse))
            }
          }).catch(() => {})
        )
        return cachedResponse
      }

      // Não tem no cache, tenta rede
      return fetch(event.request).then(networkResponse => {
        if (networkResponse.ok) {
          const cloned = networkResponse.clone()
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, cloned))
        }
        return networkResponse
      }).catch(() => {
        // Se offline e é navegação, retorna página offline
        if (event.request.mode === 'navigate') {
          return caches.match(OFFLINE_URL)
        }
        // Se é asset, tenta cache
        return caches.match(event.request)
      })
    })
  )
})

// Sync em background quando voltar online
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-progress') {
    console.log('[SW] Sync progress quando voltar online')
  }
})

// Push notifications (futuro)
self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : { title: 'ENEM Master', body: 'Hora de estudar! 🔥' }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>",
      badge: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>"
    })
  )
})
